/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sma_occ_ocean;

import java.util.*;

/**
 *
 * @author Gerson
 */
public class Agente {
    
    public SMA_OCC_OCEAN nAgentes = new SMA_OCC_OCEAN();
    int qtdAgs = SMA_OCC_OCEAN.numAgentes;
    
    
    final private int id;//Id do agente
    private boolean estouVivo;//se false, o agente não faz mais nada
    private boolean busy;//true para ocupado, false para livre
    //private int[] recurso = new int[4];//separa os recursos por id
    private int[] recurso = new int[qtdAgs];//separa os recursos por id
    
    private int diasSemComer; //contador de dias sem comer
    private boolean enviaProposta;// true se quiser trocar, false se não quiser
    private int ultimoAg;//Agente com o qual realizara a troca
    //private boolean[] agentesVivos = new boolean[4];
    private boolean[] agentesVivos = new boolean[qtdAgs];
    
    private int diasVivos;// Variavel para verificação da qtd de dias que ô ag sobreviveu
    
    //vou testar primeiramente com booleanas para facilitar
    private double trocaBoa;//valor alto para boa troca, valor baixo para troca ruim
    /*Devo mudar o troca aceita para Emoções*/
    private boolean trocaAceita;//variavel para auxilio dos calculos de emoções
    
    
    public Mercadoria ofertaRecurso = new Mercadoria();
    public Emocoes emocao = new Emocoes();//Deve passar os parametros biologicos

    //Variavel para encontrar valor aleatório
    private Random gerador = new Random();
    
//    /*--------------------------CONSTRUTOR -----------------------------------*/
//    
//    public Agente(int id, double O, double C, double E, double A, double N){
//
//            //setando id do agente
//            this.id = id;
//            this.estouVivo = true;
//            this.busy = false;
//            this.diasVivos = 0;
//
//            this.diasSemComer = 0;
//            this.ultimoAg = -1;// -1 para mostrar que ainda não houve trocas
//            
//            //fazendo generico
//            for(int i=0;i<qtdAgs;i++){
//                this.recurso[i] = 0;
//                this.agentesVivos[i] = true;
//            }
//            this.recurso[this.id] = 5;
//            /*
//            //setando os recursos iniciais do agente
//            this.recurso[0] = 0;
//            this.recurso[1] = 0;
//            this.recurso[2] = 0;
//            this.recurso[3] = 0;
//            this.recurso[id] = 5;
//            
//            this.agentesVivos[0] = true;
//            this.agentesVivos[1] = true;
//            this.agentesVivos[2] = true;
//            this.agentesVivos[3] = true;
//            */
//            
//            this.emocao.modelo.pBiologico.setOcean(O, 'O');
//            this.emocao.modelo.pBiologico.setOcean(C, 'C');
//            this.emocao.modelo.pBiologico.setOcean(E, 'E');
//            this.emocao.modelo.pBiologico.setOcean(A, 'A');
//            this.emocao.modelo.pBiologico.setOcean(N, 'N');
//            
//            
//            
//    }
      public Agente(int id, double O, double C, double E, double A, double N,double O2, double C2, double E2, double A2, double N2){

            //setando id do agente
            this.id = id;
            this.estouVivo = true;
            this.busy = false;
            this.diasVivos = 0;

            this.diasSemComer = 0;
            this.ultimoAg = -1;// -1 para mostrar que ainda não houve trocas
            
            //fazendo generico
            for(int i=0;i<qtdAgs;i++){
                this.recurso[i] = 0;
                this.agentesVivos[i] = true;
            }
            this.recurso[this.id] = 5;
            /*
            //setando os recursos iniciais do agente
            this.recurso[0] = 0;
            this.recurso[1] = 0;
            this.recurso[2] = 0;
            this.recurso[3] = 0;
            this.recurso[id] = 5;
            
            this.agentesVivos[0] = true;
            this.agentesVivos[1] = true;
            this.agentesVivos[2] = true;
            this.agentesVivos[3] = true;
            */
            
            this.emocao.modelo.pBiologico.setOcean(O, 'O');
            this.emocao.modelo.pBiologico.setOcean(C, 'C');
            this.emocao.modelo.pBiologico.setOcean(E, 'E');
            this.emocao.modelo.pBiologico.setOcean(A, 'A');
            this.emocao.modelo.pBiologico.setOcean(N, 'N');
            this.emocao.modelo.pAmbiental.setOcean(O2, 'O');
            this.emocao.modelo.pAmbiental.setOcean(C2, 'C');
            this.emocao.modelo.pAmbiental.setOcean(E2, 'E');
            this.emocao.modelo.pAmbiental.setOcean(A2, 'A');
            this.emocao.modelo.pAmbiental.setOcean(N2, 'N');
            
    }
    
    /*-----------MÉTODOS DE CALCULO E ATUALIZAÇÃO DE VARIÁVEIS ---------------*/
    
    // Calcula valor de necessidade de Agente realizar troca
    private double necessidade(){
            double n = 1;
            int qtd = verificaRecurso();
            for(int i=0;i<qtd;i++)
            {
                    n = n * 0.85;
            }
            return n;
            
    }
    
    //Calcula se o agente tem desejo de realizar troca
    //Com base em sua necessidade e suas personalidades C e E
    public boolean desejoTroca(){
        if(this.estouVivo){//Se o agente está vivo
            double n = necessidade();
            double prob;
            double aleatorio = gerador.nextDouble();
            prob = (this.emocao.modelo.pAmbiental.getOcean('C') +this.emocao.modelo.pAmbiental.getOcean('E') + n)/3;//Dando peso 2 para os pesos OCEAN
            if(aleatorio<prob && this.recurso[this.id]>0){
                //pode gerar hope ou fear
                this.emocao.setSolicitarTroca(true);
                //System.out.println("Ag"+this.id+" quer trocar!");
                this.emocao.calculaEmocaoExpectativa();
                return true;
            }
            else{//se não for realizar troca, ja pode atualizar as variaveis
                this.emocao.setSolicitarTroca(false);
                fimDia();
                return false;
            }
        }
        else{
            //System.out.println("Agent "+this.id+" esta morto");
            //fimDia();
            return false;
        }
    }
    
    //Escolhe um agente para troca
    //A escolha de um novo ag depende da ultima troca e das personalidades O e N
    public int escolheAgente(){

            int aleatorio = gerador.nextInt(qtdAgs);
            double rand = gerador.nextDouble();
                    
            double trocarAg;
            trocarAg = ((1-this.trocaBoa) + this.emocao.modelo.pAmbiental.getOcean('O') + (1-this.emocao.modelo.pAmbiental.getOcean('N')))/3;

            if(this.ultimoAg == -1){
                while(aleatorio == this.id){
                    aleatorio = gerador.nextInt(qtdAgs);
                }
                this.ultimoAg = aleatorio;
                return aleatorio;
            }
            else if(rand < trocarAg){
                //Gambiarra, mas pelo menos para de escolher agente morto para troca
                //while(!this.agentesVivos[aleatorio]){
                    while((aleatorio == this.ultimoAg || aleatorio == this.id))//procurando um Ag diferente do ultimo
                    {
                        aleatorio = gerador.nextInt(qtdAgs);
                    }
                //}
                this.ultimoAg = aleatorio;
                
                return aleatorio;
                
            }
            else{
                return this.ultimoAg;
            }
    }
    
    
    //Calcula a oferta que farei para o outro agente
    public Mercadoria calculaOferta(){//Para melhorar o cara O veria o total de recursos e nunca ficaria sem nada
            int r = this.recurso[this.id];
            double n = necessidade();
            double media = (n + this.emocao.modelo.pAmbiental.getOcean('A'))/2;
            if(media < 0.5){//não preciso muito da troca
                    ofertaRecurso.m1 = 1;
                    ofertaRecurso.m2 = (int)((0.5 - media)*10)+1;
            }
            else if(media >= 0.6){//Quando há muita necessidade de troca
                    ofertaRecurso.m1 = (int)((media - 0.5)*10)+1;//pega piso
                    ofertaRecurso.m2 = 1;
                    while(ofertaRecurso.m1 > this.recurso[this.id]){//Para não deixar o agente trocar recursos que ele nao tem
                        ofertaRecurso.m1--;
                    }
            }
            else{
                    ofertaRecurso.m1 = 1;
                    ofertaRecurso.m2 = 1;
            }
                    return ofertaRecurso;
    }


    //Retorna false proposta ruim, e true para boa
    //Avaliar a proposta depende de A e da necessidade de um novo recurso
    public boolean avaliaProposta(int id, Mercadoria p){
        //Gambs para agente morto nunca trocar
        if(this.estouVivo){
            if(p.m2>this.recurso[this.id]){
                //System.out.println("Recursos insuficientes, ag"+this.id+" nao pode trocar");
                this.emocao.setAceitarTroca(false);
                return false;
            }
            else{
                double n = necessidade();
                double r1 = p.m1;
                double r2 = p.m2;
                double prop = r1/(r2*2);
                //double media = (n + this.emocao.modelo.pAmbiental.getOcean('A') + ( prop*2 )) / 4;
                double media = (prop + (this.emocao.modelo.pAmbiental.getOcean('A')*5))/6;
                double aleatorio = gerador.nextDouble();
                if(aleatorio > media){//Rejeita proposta
                    this.emocao.setAceitarTroca(false);
                    //System.out.println("ag"+this.id+" recusou a oferta do ag"+id);
                    return false;
                }
                else{// Aceita proposta
                    this.emocao.setAceitarTroca(true);
                    return true;
                }
            }
        }
        else{
                return false;
            }
    }
    
    //Calcula se fiz uma boa troca ou não
    public void calculaTrocaBoa(){
        double n = necessidade();
        //double prop = this.ofertaRecurso.m1/(this.ofertaRecurso.m2*2);//EETAA BURRICE
        double r1 = this.ofertaRecurso.m1;
        double r2 = this.ofertaRecurso.m2;
        double prop  = r2/(r1*6);
        double media = (n + this.emocao.modelo.pAmbiental.getOcean('A') + ( prop*8 )) / 10;
        //double media = prop;
        /*if(this.trocaAceita){ //Estavadando muita emoção ruim(nao precisa atualiar qnd nao foi aceita)
            this.trocaBoa = media;
        }else{//Não consegui trocar, então a "troca" foi ruim
            this.trocaBoa = media*0.1;
        }*/
        this.trocaBoa = media;
        if(this.trocaBoa > 0.4){//-----------------DEFINIÇÃO DE BOA TROCA------------------
            this.emocao.setBoaTrocaAg(true);
        }
        else{
            this.emocao.setBoaTrocaAg(false);
        }
        if(this.trocaBoa >= 0.2 && this.trocaBoa<=0.8){
            this.emocao.setBoaTrocaAmbos(true);
        }
        else{
            this.emocao.setBoaTrocaAmbos(false);
        }
        //System.out.println("Ag"+this.id);
        if(this.trocaAceita){
            this.emocao.calculaEmocaoAvaliacao();//--------CALCULO DE AVALIAÇÃO--------
        }        
    }


    //verifica quantos recursos ainda tem para sobreviver
    private int verificaRecurso(){
            int qtd = 0;
            for(int i=0;i<qtdAgs;i++){
                    qtd += getRecurso(i);
            }
            qtd -= getRecurso(this.id);
            return qtd;
    }
    
    //Atualiza as variaveis, e verifica se o agente continua vivo
    public void fimDia(){
//        if(this.id == 0){
//            System.out.println("id:"+this.emocao.modelo.pAmbiental.getOcean('O'));
//        }
        //System.out.println("Final do dia, recuros :"+this.recurso[0]+" "+this.recurso[1]+" "+this.recurso[2]+" "+this.recurso[3] +" id"+this.id );
        if(this.estouVivo){
            if(this.diasSemComer == 5){//Deve ser 5
                if(verificaRecurso() == 0){// mata o Agente
                    this.estouVivo = false;
                    //Fazendo isto porque está dando um bug de o agente morto continuar recebendo solicitação de troca
                    this.recurso[this.id] = 0;
                }
                else{// Consome algum tipo de recurso
                    for(int i=0;i<qtdAgs;i++){/*CONFIRMAR SE BREAK IRA FUNCIONAR*/
                        if(i != this.id){//Busca para consumir um recurso qualquer
                            if(this.recurso[i]>0){
                                this.recurso[i]--;
                                this.diasSemComer = 0;
                                break;
                            }
                        }
                    }
                }
            }
            else{
                this.diasSemComer++;
            }
            this.diasVivos++;
            //this.recurso[this.id]++;//Adiciona um de comida para o agente
        }
        else{
            this.recurso[this.id] = 0;
        }
       // System.out.println("id"+id+" - "+this.recurso[0]+" "+this.recurso[1]+" "+this.recurso[2]+" "+this.recurso[3]+" "+this.recurso[4]+" "+this.recurso[5]+" "+this.recurso[6]+" "+this.recurso[7]+" "+this.recurso[8]+" "+this.recurso[9]);
        
        
    }
    
    
    public void inicializaAgente(){//Criei este metodo porque java não tem destrutor
        this.estouVivo = true;
        this.busy = false;

        this.diasSemComer = 0;
        this.ultimoAg = -1;// -1 para mostrar que ainda não houve trocas
        this.diasVivos = 0;

        
        for(int i=0;i<qtdAgs;i++){
                this.recurso[i] = 0;
                this.agentesVivos[i] = true;
            }
            this.recurso[this.id] = 5;
            
        //setando os recursos iniciais do agente
        /*this.recurso[0] = 0;
        this.recurso[1] = 0;
        this.recurso[2] = 0;
        this.recurso[3] = 0;
        this.recurso[id] = 5;

        this.agentesVivos[0] = true;
        this.agentesVivos[1] = true;
        this.agentesVivos[2] = true;
        this.agentesVivos[3] = true;*/
        
        this.emocao.modelo.inicializaAtualizaOcean();
        
        if(this.id!=0){//SETANDO TODOS OS AGENTES COM SEU PBIOLOGICO (menos o ag0)
            this.emocao.modelo.pAmbiental.setOcean(0, this.emocao.modelo.pBiologico.getOcean(0));
            this.emocao.modelo.pAmbiental.setOcean(1, this.emocao.modelo.pBiologico.getOcean(1));
            this.emocao.modelo.pAmbiental.setOcean(2, this.emocao.modelo.pBiologico.getOcean(2));
            this.emocao.modelo.pAmbiental.setOcean(3, this.emocao.modelo.pBiologico.getOcean(3));
            this.emocao.modelo.pAmbiental.setOcean(4, this.emocao.modelo.pBiologico.getOcean(4));
        }
    }
    
    /*---------------------GETTER AND SETTERS -----------------------*/
    
    //Getter id
    public int getId(){
            return this.id;
    }
    
    //Getter and Setter estouVivo
    public boolean getEstouVivo(){
        return this.estouVivo;
    }
    public void setEstouVivo(boolean vivo){
        this.estouVivo = vivo;
    }

    //Getter and Setter Busy
    public boolean getBusy(){
            return this.busy;
    }
    public void setBusy(boolean busy){
            this.busy = busy;
    }

    //Métodos para Recursos
    public int getRecurso(int id){
            return this.recurso[id];
    }
    public void addRecurso(int qtd, int id){
            this.recurso[id] += qtd;
    }
    public void subRecurso(int qtd, int id){
            this.recurso[id] -= qtd;
    }

    //Getter and Setter para ultimoAg
    public int getUltimoAg(){
            return this.ultimoAg;
    }
    public void setUltimoAg(int ag){
            this.ultimoAg = ag;
    }

    //Getter and Setter para trocaBoa
    public double getTrocaBoa(){
            return this.trocaBoa;
    }
    public void setTrocaBoa(double troca){
            this.trocaBoa = troca;
    }


    //Métodos para diasSemComer
    public int getDiasSemComer()
    {
            return this.diasSemComer;
    }
    public void addDiasSemComer()
    {
            this.diasSemComer++;
    }
    public void zeraDiasSemComer(){
            this.diasSemComer = 0;
    }
    
    // Getter and setter para enviaProposta
    public boolean getEnviaProposta(){
        return this.enviaProposta;
    }
    public void setEnviaProposta(boolean p){
        this.enviaProposta = p;
    }
    
    //Getter and Setter trocaAveita
    public boolean getTrocaAceita(){
        return this.trocaAceita;
    }
    public void setTrocaAceita(boolean p){
        this.trocaAceita = p;
    }
    
    // Getter and Setter para ofertaRecurso
    public Mercadoria getOfertaRecurso(){
        return this.ofertaRecurso;
    }
    public void setOfertaRecurso(Mercadoria m){
        this.ofertaRecurso = m;
    }
 
    public void setAgenteMorto(int id){
        this.agentesVivos[id] = false;
    }
    
    public void setDiasVivos(int qtd){
        this.diasVivos = qtd;
    }
    
    public int getDiasVivos(){
        return this.diasVivos;
    }

}




