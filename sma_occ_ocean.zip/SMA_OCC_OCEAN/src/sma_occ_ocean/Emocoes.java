
package sma_occ_ocean;

import java.util.Random;

/**
 *
 * @author Gerson
 */
public class Emocoes {
    //Variavel para encontrar valor aleatório
    private Random gerador = new Random();
    
    /*Variaveis para auxiliar na geração de emoções*/
    /*-----------------------Variaveis do meu modelo--------------------------*/
    private boolean solicitarTroca;
    private boolean receberSolicitacao;
    private boolean trocaAceita;// false para troca negada//tem que ser int de 0 a 2
    private boolean aceitarTroca;// false para rejeitar troca//tem que ser int 
    private boolean boaTrocaAg;//uma para solicitado e outra para recebido
    private boolean boaTrocaAmbos;//uma para solicitado e outra para recebido
    
    //Variaveis para controle dos pesos de multiplicação e divisão referentes
    // a probabilidade de uma emoção ser escolhida
    private final double fMul = 0;//40//Variavel para multiplicação do peso OCEAN
    private final double fBt = 100;//50//Variavel para setar o peso de bt e bta
    private final double fRand = 0;//10//Variavel para setar a chance de uma emoção acontecer aleatoriamente(em porcentagem)
    private final double fDiv = 100;//Variavel para divisão das somas
    //private final double fDiv = fMul+fBt+fRand;//Variavel para divisão das somas
    
    public int contaTrocas = 0;
    
    private boolean hope;
    
    public AtualizaOcean modelo = new AtualizaOcean();
    
    public Emocoes(){
        
    }
    
    //Metodos para calculo de emoções quando estou solicitando trocas
    public void calculaEmocaoExpectativa(){//Deveira ter um peso menor na atualização
        if(this.solicitarTroca){
            //System.out.println("Calculando emoção de espectativa");
            double prob = this.gerador.nextDouble();
            if(this.modelo.pAmbiental.getOcean('N')<=prob){
                //this.occ.addOcc(6, 0.5);//ta errado pq na vdd sempre q sente a emoção ja atualiza o ocean
                //this.modelo.occ.setOcc(6, 1);//Hope
                this.modelo.atualizaPersonalidade(6);
                //this.modelo.mostraEmocao(6);
                this.hope = true;
            }
            else{
                //this.modelo.occ.setOcc(7, 1);//Fear
                this.modelo.atualizaPersonalidade(7);
                //this.modelo.mostraEmocao(7);
                this.hope = false;
                //System.out.println("Fear");
            }
        }
        //this.modelo.atualizaOCEAN();
    }
    
    public void calculaEmocaoRealizacao(){//ISSO DEVERIA TER UM POUCO DE PROB TB//Deveira ter um peso menor na atualização
        if(trocaAceita){this.contaTrocas++;}
        else{this.contaTrocas--;}
        //System.out.println("Calculando emoção de realização");
        if(trocaAceita == true && hope == true){
            //this.modelo.occ.setOcc(8, 1.2);//Satisfaction(8)
            this.modelo.atualizaPersonalidade(8);
            //this.modelo.mostraEmocao(8);
        }
        else if(trocaAceita == true && hope == false){
            //this.modelo.occ.setOcc(10, 1.2);//Relief(10)
            this.modelo.atualizaPersonalidade(10);
            //this.modelo.mostraEmocao(10);
        }
        else if(trocaAceita == false && hope == true){
            //this.modelo.occ.setOcc(11, 1.2);//Disapointment(11)
            this.modelo.atualizaPersonalidade(11);
            //this.modelo.mostraEmocao(11);
        }
        else if(trocaAceita == false && hope == false){
            //this.modelo.occ.setOcc(9, 1.2);//Fears-Confirmed(9)
            this.modelo.atualizaPersonalidade(9);
            //this.modelo.mostraEmocao(9);
        }
        //this.modelo.atualizaOCEAN();
    }
    
    public void calculaEmocaoAvaliacao(){//Possivelmente implementarei alguma rede neural
        //System.out.println("Calculando emoção de avaliação");
        double prob;
        double bt, bta, BN;
        /*Dependendo de boaTrocaAg*/
        if(boaTrocaAg){ bt = fBt; BN = 0;}
        else { bt = 0; BN = fBt;}
        if(boaTrocaAmbos){ bta = fBt; }
        else { bta = 0; }
        
        ///*
        //Modelo que não parece estar dando certo
        prob = this.gerador.nextDouble();
        if((((this.modelo.pAmbiental.getOcean('N')*fMul)/2)+0+BN)/fDiv < prob){//------------------------------------------BOA
            this.modelo.occ.setOcc(0, 1);//Joy(0)
        }
        //prob = this.gerador.nextDouble();
        else if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bt)/fDiv > prob){//------------------------------------------BOA
            this.modelo.occ.setOcc(4, 1);//Glaoting(4)
        }
        //prob = this.gerador.nextDouble();
        else if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bt)/fDiv > prob){//------------------------------------------BOA
            this.modelo.occ.setOcc(18, 1);//Gratitude(18)
        }
        //prob = this.gerador.nextDouble();
        else if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bt)/fDiv > prob){//------------------------------------------BOA
            this.modelo.occ.setOcc(16, 1);//Gratification(16) += 0.25
        }
        
        //Modifiquei as condições
        //prob = this.gerador.nextDouble();
        else if((((this.modelo.pAmbiental.getOcean('N')*fMul)/2)+fRand+BN)/fDiv > prob){
            this.modelo.occ.setOcc(1, 1);//Distress(1)
        }
        //prob = this.gerador.nextDouble();
        else if((((0.5-this.modelo.pAmbiental.getOcean('A'))*fMul)+0+bt)/fDiv > prob){//-------MUDAR O A-----------
            this.modelo.occ.setOcc(5, 1);//Ressentment(5)
        }
        //prob = this.gerador.nextDouble();
        else if((((0.5-this.modelo.pAmbiental.getOcean('A'))*fMul)+0+bt)/fDiv > prob){
            this.modelo.occ.setOcc(19, 1);//Anger(19)
        }
        //prob = this.gerador.nextDouble();
        else if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bt)/fDiv > prob){
            this.modelo.occ.setOcc(17, 1);////Remorse(17)
        }
        //*/
        
        
        /*
        //Modelo que não parece estar dando certo
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('N')*fMul)+0+bt)/fDiv <= prob){//------------------------------------------BOA
            this.modelo.occ.setOcc(0, 1);//Joy(0)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bt)/fDiv >= prob){//------------------------------------------BOA
            this.modelo.occ.setOcc(4, 1);//Glaoting(4)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bt)/fDiv >= prob){//------------------------------------------BOA
            this.modelo.occ.setOcc(18, 1);//Gratitude(18)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bt)/fDiv >= prob){//------------------------------------------BOA
            this.modelo.occ.setOcc(16, 1);//Gratification(16) += 0.25
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('N')*fMul)+fRand+bt)/fDiv >= prob){
            this.modelo.occ.setOcc(1, 1);//Distress(1)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+0+bt)/fDiv <= prob){//-------MUDAR O A-----------
            this.modelo.occ.setOcc(5, 1);//Ressentment(5)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+0+bt)/fDiv <= prob){
            this.modelo.occ.setOcc(19, 1);//Anger(19)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bt)/fDiv >= prob){
            this.modelo.occ.setOcc(17, 1);////Remorse(17)
        }

        //boa troca ambos
        //prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('E')*fMul)+fRand+bta)/fDiv >= prob){//(((this.getAmbOCEAN('E')*4)+1+bta)/10 >= prob)
            this.modelo.occ.setOcc(12, 1);//Pride(12)
        }
        //prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(4, 1);//Glaoting(4)
        }
        //prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(2, 1);//Happy-for(2)
        }
        //prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(16, 1);//Gratification(16)
        }
       

        //prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('E')*fMul)+0+bta)/fDiv <= prob){
            this.modelo.occ.setOcc(13, 1);//Shame(13)
        }
        //prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(5, 1);//Resentment(5)
        }
        //prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(3, 1);//Pity(3)
        }
        //prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(17, 1);//Remorse(17)
        }
        //*/
        
        /*
        //Novo método (estava errado o > em vez de <
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('N')*fMul)+0+BN)/fDiv <= prob){// TEM QUE SER DIFERENTE DOS OUTROS
            this.modelo.occ.setOcc(0, 1);//Joy(0)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bt)/fDiv >= prob){//Dando peso dois para o ocean//-------MUDAR O A-----------
            this.modelo.occ.setOcc(4, 1);//Glaoting(4)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bt)/fDiv >= prob){//(((this.getAmbOCEAN('A')*4)+1+bt)/10 >= prob)
            this.modelo.occ.setOcc(18, 1);//Gratitude(18)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bt)/fDiv >= prob){
            this.modelo.occ.setOcc(16, 1);//Gratification(16) += 0.25
        }
        
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('N')*fMul)+fRand+BN)/fDiv >= prob){
            this.modelo.occ.setOcc(1, 1);//Distress(1)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+0+bt)/fDiv <= prob){//-------MUDAR O A-----------
            this.modelo.occ.setOcc(5, 1);//Ressentment(5)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+0+bt)/fDiv <= prob){
            this.modelo.occ.setOcc(19, 1);//Anger(19)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bt)/fDiv <= prob){
            this.modelo.occ.setOcc(17, 1);////Remorse(17)
        }

        //boa troca ambos
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('E')*fMul)+fRand+bta)/fDiv >= prob){//(((this.getAmbOCEAN('E')*4)+1+bta)/10 >= prob)
            this.modelo.occ.setOcc(12, 1);//Pride(12)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(4, 1);//Glaoting(4)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(2, 1);//Happy-for(2)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bta)/fDiv >= prob){
            this.modelo.occ.setOcc(16, 1);//Gratification(16)
        }
       

        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('E')*fMul)+0+bta)/fDiv <= prob){
            this.modelo.occ.setOcc(13, 1);//Shame(13)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bta)/fDiv <= prob){
            this.modelo.occ.setOcc(5, 1);//Resentment(5)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('A')*fMul)+fRand+bta)/fDiv <= prob){
            this.modelo.occ.setOcc(3, 1);//Pity(3)
        }
        prob = this.gerador.nextDouble();
        if(((this.modelo.pAmbiental.getOcean('C')*fMul)+fRand+bta)/fDiv <= prob){
            this.modelo.occ.setOcc(17, 1);//Remorse(17)
        }
       */
        this.modelo.atualizaOCEAN();
    }
    
    public boolean getSolicitarTroca(){
        return this.solicitarTroca;
    }
    public void setSolicitarTroca(boolean sT){
        this.solicitarTroca = sT;
    }
    
    public boolean getReceberSolicitacao(){
        return this.receberSolicitacao;
    }
    public void setReceberSolicitacao(boolean rS){
        this.receberSolicitacao = rS;
    }
    
    public boolean getTrocaAceita(){
        return this.trocaAceita;
    }
    public void setTrocaAceita(boolean tA){
        this.trocaAceita = tA;
    }
    
    public boolean getAceitarTroca(){
        return this.aceitarTroca;
    }
    public void setAceitarTroca(boolean aT){
        this.aceitarTroca = aT;
    }
    
    public boolean getBoaTrocaAg(){
        return this.boaTrocaAg;
    }
    public void setBoaTrocaAg(boolean bTA){
        this.boaTrocaAg = bTA;
    }
    
    public boolean getBoaTrocaAmbos(){
        return this.boaTrocaAmbos;
    }
    public void setBoaTrocaAmbos(boolean bTA){
        this.boaTrocaAmbos = bTA;
    }
}
