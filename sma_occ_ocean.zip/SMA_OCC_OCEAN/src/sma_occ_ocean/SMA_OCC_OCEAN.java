/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sma_occ_ocean;

import java.math.*;

/**
 *
 * @author Gerson
 */
public class SMA_OCC_OCEAN {

    /**
     * @param args the command line arguments
     */
    
    //Variaveis de controle de simulação
    static int numSimulacoes = 100;
    static int numIteracoes = 10000;
    static int numAgentes = 4;
    
    //Variaveis para calculos
    static double[][] somatorio = new double[numAgentes][5];
    static double[][] media = new double[numAgentes][5];
    static double[][] desvio = new double[numAgentes][5];
    
    
    //Variaveis para agentes
    static double[][][] agente = new double[numAgentes][5][numSimulacoes];
    static double[][] ag0 = new double[5][numSimulacoes];
    static double[][] ag1 = new double[5][numSimulacoes];
    static double[][] ag2 = new double[5][numSimulacoes];
    static double[][] ag3 = new double[5][numSimulacoes];//recebe os valores de cada agente 
    
    //Variaveis para verificação dos dias sobrevividos
    static int[][] diasVivos = new int[numAgentes][numSimulacoes];
    static int[] somaDias = new int[numAgentes];
    static double[] mediaDias = new double[numAgentes];
    static int[] maxDias = new int[numAgentes];
    static int[] minDias = new int[numAgentes];//numIteracoes;
    
    
    public static void main(String[] args) {
        
        inicializaSomatorio();
        
        Agente[] ag = new Agente[numAgentes];
        //ag[0] = new Agente(0, 0.6, 0.8, 0.6, 0.8, 0.3);
        //ag[1] = new Agente(1, 0.3, 0.3, 0.3, 0.2, 0.7);
        //ag[2] = new Agente(2, 0.3, 0.3, 0.3, 0.2, 0.7);
        //ag[3] = new Agente(3, 0.3, 0.3, 0.3, 0.2, 0.7);
        //ag[4] = new Agente(4, 0.5, 0.6, 0.3, 0.2, 0.7);
        //ag[5] = new Agente(5, 0.5, 0.6, 0.3, 0.2, 0.7);
        //ag[6] = new Agente(6, 0.5, 0.6, 0.3, 0.2, 0.7);
        //ag[7] = new Agente(7, 0.5, 0.6, 0.3, 0.2, 0.7);
        //ag[8] = new Agente(8, 0.5, 0.6, 0.3, 0.2, 0.7);
        //ag[9] = new Agente(9, 0.5, 0.6, 0.3, 0.2, 0.7);
        
        
        //ag[0] = new Agente(0, 0.3, 0.8, 0.3, 0.2, 0.8);
        //ag[1] = new Agente(1, 0.6, 0.8, 0.6, 0.9, 0.5);
        //ag[2] = new Agente(2, 0.6, 0.8, 0.6, 0.9, 0.5);
        //ag[3] = new Agente(3, 0.6, 0.8, 0.6, 0.9, 0.5);
        //ag[4] = new Agente(4, 0.5, 0.8, 0.5, 0.8, 0.3);
        //ag[5] = new Agente(5, 0.5, 0.8, 0.5, 0.8, 0.3);
        //ag[6] = new Agente(6, 0.5, 0.8, 0.5, 0.8, 0.3);
        //ag[7] = new Agente(7, 0.5, 0.8, 0.5, 0.8, 0.3);
        //ag[8] = new Agente(8, 0.5, 0.8, 0.5, 0.8, 0.3);
        //ag[9] = new Agente(9, 0.5, 0.8, 0.5, 0.8, 0.3);

        //Neutro
        //ag[0] = new Agente(0, 0.5, 0.5, 0.5, 0.5, 0.5);
        //Bons
        //ag[0] = new Agente(0, 0.9, 0.9, 0.9, 0.9, 0.1);
        ag[1] = new Agente(1, 1, 1, 1, 1, 0.1, 1, 1, 1, 1, 0.1);
        ag[2] = new Agente(2, 1, 1, 1, 1, 0.1, 1, 1, 1, 1, 0.1);
        ag[3] = new Agente(3, 1, 1, 1, 1, 0.1, 1, 1, 1, 1, 0.1);
        
        //Ruins
        ag[0] = new Agente(0, 0.1, 0.1, 0.1, 0.1, 0.9, 0.1, 0.1, 0.1, 0.1, 0.9);
        //ag[1] = new Agente(1, 0.0, 0.0, 0.0, 0.0, 0.9);
        //ag[2] = new Agente(2, 0.0, 0.0, 0.0, 0.0, 0.9);
        //ag[3] = new Agente(3, 0.0, 0.0, 0.0, 0.0, 0.9);
        
        for(int i=0;i<numSimulacoes;i++){
            ModeloTroca model = new ModeloTroca(numAgentes, ag);
            for(int j=0;j<numIteracoes;j++){
                model.inicializa();
            }
            for(int k=0;k<5;k++){//Leitura dos 5 OCEAN
                ag0[k][i] = model.ag[0].emocao.modelo.pAmbiental.getOcean(k);
                ag1[k][i] = model.ag[1].emocao.modelo.pAmbiental.getOcean(k);
                ag2[k][i] = model.ag[2].emocao.modelo.pAmbiental.getOcean(k);
                //ag3[k][i] = model.ag[3].emocao.modelo.pAmbiental.getOcean(k);
            }
            System.out.println("ag0: "+ag0[0][i]+" "+ag0[1][i]+" "+ag0[2][i]+" "+ag0[3][i]+" "+ag0[4][i]);
            //System.out.println("Iniciando proxima \n\n");
            for(int k=0;k<numAgentes;k++){
                diasVivos[k][i] = model.ag[k].getDiasVivos();
            }
            //System.out.println("diasVivos: "+ diasVivos[0][i]);
        }
        System.out.println("Numero de Simulacoes: "+numSimulacoes+" - Numero de Iteracoes: "+numIteracoes);
        System.out.println("Contador ----> "+ag[0].emocao.modelo.emocoesBoas);
        System.out.println("Trocas   ----> "+ag[0].emocao.contaTrocas);
        calculaMedia();
        calculaDesvio();
        calculaDias();
        
    }
    
    
    static void inicializaSomatorio(){
        for(int i=0;i<numAgentes;i++){
            for(int j=0;j<5;j++){
                somatorio[i][j]=0;
            }
        }
    }
    
    static void calculaMedia(){
        double[][] max = new double[numAgentes][5];
        double[][] min = new double[numAgentes][5];
        
        for(int i=0;i<numSimulacoes;i++){
            for(int j=0;j<5;j++){
                somatorio[0][j]+=ag0[j][i];
                somatorio[1][j]+=ag1[j][i];
                somatorio[2][j]+=ag2[j][i];
//                somatorio[3][j]+=ag3[j][i];
                
            }
        }
        for(int i=0;i<numAgentes;i++){
            for(int j=0;j<5;j++){
                media[i][j]=somatorio[i][j]/numSimulacoes;
            }
        }
        for(int i=0;i<numAgentes;i++){
            System.out.println("Media Ag"+i+" : "+media[i][0]+" "+media[i][1]+" "+media[i][2]+" "+media[i][3]+" "+media[i][4]+" ");   
        }
    }
    static void calculaDesvio(){
        double[][] somDesvio = new double[numAgentes][5];
        double[][] s = new double[numAgentes][5];
        double aux;
        for(int i=0;i<numAgentes;i++){
            for(int j=0;j<5;j++){
                somDesvio[i][j] = 0;
            }
        }
        for(int i=0;i<numSimulacoes;i++){//Fazendo os somatorios
            for(int j=0;j<5;j++){
                //aux = ag0[j][i] - media[0][j];
                //ARRUMAR
                somDesvio[0][j] = ((ag0[j][i] - media[0][j])*(ag0[j][i] - media[0][j]))+somDesvio[0][j];//+= Math.pow(aux, 2);
                aux = ag1[j][i] - media[1][j];
                somDesvio[1][j] += Math.pow(aux, 2);//somDesvio[1][j]*somDesvio[1][j];
                aux = ag2[j][i] - media[2][j];
                somDesvio[2][j] += Math.pow(aux, 2);
                aux = ag3[j][i] - media[3][j];
                somDesvio[3][j] += Math.pow(aux, 2);
            }
        }
        for(int j=0;j<5;j++){
            s[0][j] = somDesvio[0][j]/(numSimulacoes-1);
            s[0][j] = Math.sqrt(s[0][j]);
            //s[1][j] = (1/(numSimulacoes-1))*somDesvio[1][j]; -- NAO FUNCIONA!!
            s[1][j] = somDesvio[1][j]/(numSimulacoes-1);
            s[1][j] = Math.sqrt(s[1][j]);
            s[2][j] = somDesvio[2][j]/(numSimulacoes-1);
            s[2][j] = Math.sqrt(s[2][j]);
            s[3][j] = somDesvio[3][j]/(numSimulacoes-1);
            s[3][j] = Math.sqrt(s[3][j]);
        }
        for(int i=0;i<numAgentes;i++){
            System.out.println("Desvio Ag"+i+" : "+s[i][0]+" "+s[i][1]+" "+s[i][2]+" "+s[i][3]+" "+s[i][4]+" ");
        }   
    }
    
    static void calculaDias(){
        double[] somDesvio = new double[numAgentes];
        double[] s = new double[numAgentes];
        double aux =0;
        for(int i =0;i<numAgentes; i++){//Apenas "zerando" o min e max
            maxDias[i] = 0;
            minDias[i] = numIteracoes;
            mediaDias[i] = 0;
            somaDias[i] = 0;
            somDesvio[i] = 0;
            s[i] = 0;
        }
        for(int i=0;i<numAgentes;i++){
            for(int j=0;j<numSimulacoes;j++){
                somaDias[i] += diasVivos[i][j];
                if(diasVivos[i][j]>=maxDias[i]){
                    maxDias[i] = diasVivos[i][j];
                }
                if(diasVivos[i][j]<minDias[i]){
                    minDias[i] = diasVivos[i][j];
                }
            }
        }
        for(int i=0;i<numAgentes;i++){
            mediaDias[i] = somaDias[i]/numSimulacoes;
        }
        //Descobrindo desvio padrão
        for(int i=0;i<numAgentes;i++){
            for(int j=0;j<numSimulacoes;j++){
                aux = (diasVivos[i][j] - mediaDias[i]);
                somDesvio[i] += Math.pow(aux,2);
            }
        }
        for(int i=0;i<numAgentes;i++){
            s[i] = Math.sqrt(somDesvio[i]/(numSimulacoes-1));
        }
        //Calcular também o desvio padrão
        System.out.println("media DiasVividos: "+mediaDias[0]+" "+mediaDias[1]+" "+mediaDias[2]+" "+mediaDias[3]);
        System.out.println("Max DiasVividos: "+maxDias[0]+" "+maxDias[1]+" "+maxDias[2]+" "+maxDias[3]);
        System.out.println("Min DiasVividos: "+minDias[0]+" "+minDias[1]+" "+minDias[2]+" "+minDias[3]);
        System.out.println("Desvio DiasVividos: "+s[0]+" "+s[1]+" "+s[2]+" "+s[3]+" ");
    }
    
}


//Configuração em que geralmente todos sobrevivem
        /*ag[0] = new Agente(0, 0.5, 0.8, 0.5, 0.9, 0.3);
        ag[1] = new Agente(1, 0.5, 0.8, 0.5, 0.9, 0.7);
        ag[2] = new Agente(2, 0.5, 0.8, 0.5, 0.8, 0.7);
        ag[3] = new Agente(3, 0.5, 0.8, 0.5, 0.8, 0.3);*/