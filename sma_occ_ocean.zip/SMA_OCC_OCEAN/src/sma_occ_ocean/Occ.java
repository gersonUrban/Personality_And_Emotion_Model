/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sma_occ_ocean;

/**
 *
 * @author Gerson
 */
public class Occ {
    private double[] OCC = new double[22];
    
    Occ(){
        for(int i=0;i<22;i++){
            this.OCC[i] = 0;
        }
    }
    
    public double getOcc(int i){
        return this.OCC[i];
    }
    public void setOcc(int i, double valor){
        this.OCC[i] = valor;
    }
    public void addOcc(int i, double valor){
        this.OCC[i] += valor;
    }
    public void zeraOcc(int i){
        this.OCC[i] = 0;
    }
    public void zeraOcc(){
        for(int i=0;i<22;i++){
            this.OCC[i] = 0;
        }
    }
    
}