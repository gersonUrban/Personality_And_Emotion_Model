/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sma_occ_ocean;

import java.math.*;
import java.util.Random;
/**
 *
 * @author Gerson
 */
public class AtualizaOcean {
    private Random gerador = new Random();
    //Constantes para calculo do modelo//
    private final double e = Math.E;// 2.718281828459;
    private double divisorFx = 100;
    private final double multFP = 2.5;
    private final double K = 8;
    private final double X00 = 0.0000001;
    
    public Ocean pAmbiental = new Ocean();
    public Ocean pBiologico = new Ocean();
    public Occ occ = new Occ(); 
    public int emocoesBoas = 0;
    


    private int tempo = 0;
    private double[] x = new double[5];
    // vetor que representa o estado emocional
    private Occ et = new Occ();
    // vetor referente a informacao emocional
    // definida como uma mudanca de desejo na intensidade emocional para cada emocao
    // Eh basicamente o valor de entrada que corresponde as interacoes com o meio
    //no artigo eh o vetor 'a'
    private Occ a = new Occ();
    
    private OCCxOCEAN P0 = new OCCxOCEAN(0);
    private OCCxOCEAN P1 = new OCCxOCEAN(0);
    private OCCxOCEAN P2 = new OCCxOCEAN(1);
    //importancia de cada emocao dependendo da personalidade
    //esta matriz eh toda zerada, somente com valores da diagonal principal
    //no artigo eh a matriz 'P'
    private double[][] P = new double[22][22];//double P[OCC][OCC];
    //vetor que pega o resultado do produto entre 'P0' e 'p'
    //para depois se tornar a diagonal principal de 'P'
    //no artigo eh o vetor 'u'
    private Occ u = new Occ();//double u[OCC];
    //vetor responsavel por fazer o decaimento temporal dos pesos das emocoes
    // no artigo Ã© onde tem o peso 'Ce' = -0,1
    private Occ Ce = new Occ();//double Ce[OCC];
    //errei alguma coisa e faltou esse vetor... (eh necessario ter?)
    //---------arrumar-----------
    private Occ emotionalHistory = new Occ(); //double emotionalHistory[OCC];
    
    public AtualizaOcean(){
//        this.pAmbiental.setOcean(0.5, 'O');
//        this.pAmbiental.setOcean(0.5, 'C');
//        this.pAmbiental.setOcean(0.5, 'E');
//        this.pAmbiental.setOcean(0.5, 'A');
//        this.pAmbiental.setOcean(0.5, 'N');
        
	inicializaX();
        for(int i=0;i<22;i++){
            this.Ce.setOcc(i, -0.01);
            for(int j=0;j<22;j++)
            {
		P[i][j]=0.0;
            }
        }
        //apenasParaTestes();
    }
    
    public void inicializaAtualizaOcean(){
       /* this.pAmbiental.setOcean(0.5, 'O');
        this.pAmbiental.setOcean(0.5, 'C');
        this.pAmbiental.setOcean(0.5, 'E');
        this.pAmbiental.setOcean(0.5, 'A');
        this.pAmbiental.setOcean(0.5, 'N');
       */ 
	inicializaX();

        this.a.zeraOcc();
        this.occ.zeraOcc();
        this.emotionalHistory.zeraOcc();
        this.et.zeraOcc();
        this.u.zeraOcc();
        
        for(int i=0;i<22;i++){
            this.Ce.setOcc(i, -0.01);
            for(int j=0;j<22;j++)
            {
		P[i][j]=0.0;
            }
        }
        this.tempo = 0;
    }
    
    
    /*Modelo de atualização dos pesos OCEAN*/
    public void atualizaOCEAN(){
	
        for(int i=0;i<22;i++){
            this.a.setOcc(i, this.occ.getOcc(i));
        }
        //Aqui comeca o modelo do artigo
        //cout<<"Multiplicando P0 x p\n";
        multiplicaP0xp();

        //Atualiza matriz P
        atualizaP();

        //encontrando o valor et atual (vetor referente a informacao emocional)
        multiplicaPxa();

        // Calculando vetor dos pesos de emocoes a serem sentidas
        atualiza_et();
        
        //Atualizando Pesos OCEAN
        int em = verificaEmocao();
        
        atualizaPersonalidade(em);
        //mostraEmocao(em);
        this.occ.zeraOcc();
   
        //apenasParaTestes();
    }
    
    /*---------------funções do modelo do artigo----------------*/
    //Multiplicacao da matriz de pesos iniciais com as personalidades
    private void multiplicaP0xp()
    {
        for(int i=0;i<22;i++)
        {
            this.u.zeraOcc(i);
            for(int j=0;j<5;j++)
            {
                if(this.pAmbiental.getOcean(j)>=0.5)
                {
                    this.u.addOcc(i, (this.P1.getOCCxOCEAN(i, j)*this.pAmbiental.getOcean(j))/5);//u[i] += (P1[i][j]*p[j])/5;//P0
                }
                else
                {
                    this.u.addOcc(i, (this.P2.getOCCxOCEAN(i, j)*(1-this.pAmbiental.getOcean(j)))/5);//u[i] += (P2[i][j]*(1-p[j]))/5;
                }
            }
        }
    }
    // Gerando a matriz identidade, para poder multiplicar com o vetor de influencia de emocoes
    private void atualizaP()
    {
        for(int i=0;i<22;i++)
        {
            this.P[i][i] = this.u.getOcc(i);//P[i][i]=u[i];
        }
    }
    //Multiplicacao da matriz identidade com vetor de influencia
    private void multiplicaPxa()
    {
        double aux;
        for(int i=0;i<22;i++)
        {
            this.emotionalHistory.zeraOcc(i);//emotionalHistory[i] = 0;
            for(int j=0;j<22;j++)
            {
                this.emotionalHistory.addOcc(i, this.a.getOcc(j)*this.P[i][j]);//emotionalHistory[i] += a[j]*P[i][j];
                //et[i] += a[j]*P[i][j];
            }
            //cout<<emotionalHistory[i]<<" ";//mostrando emotionalHistory para demonstraÃ§Ã£o em artigo----------
        }
        //cout<<endl;
    }
    // Formula de atualizacao do estado emocional
    private void atualiza_et()
    {
        for(int i=0; i<22;i++)
        {
            this.et.addOcc(i, this.emotionalHistory.getOcc(i)+this.Ce.getOcc(i));//et[i] = et[i] + emotionalHistory[i] + Ce[i];
            if(this.et.getOcc(i)< 0){
                this.et.zeraOcc(i);
            }
            if(this.et.getOcc(i) > 1){
                this.et.setOcc(i, 1);
            }
        }
    }
    
    //funcoes de atualizacao da personalidade
    // Funcao inicial para se encontrar o valor de x
    //Deve ser inicializada logo no comeco
    private void inicializaX()
    {
        double aux;
        for(int i=0;i<5;i++)
        {
            //aux = sqrt( p[i]/(1-p[i]) );//para k=2
            //aux = p[i]/(1-p[i]);//para k=1
            aux = (1-this.pAmbiental.getOcean(i))/this.pAmbiental.getOcean(i);//(1-p[i])/p[i];
            this.x[i] = (-K)*Math.log(aux);//x[i] = (-K)*log(aux);
        }
    } 
    
    //FunÃ§Ãµes para atualizar o valor de x

    //------------------PRECISO ARRUMAR AS CONSTANTES DE DIVISÃƒO---------------------------//
            //(quais as constantes de divisão?)
    // FunÃ§Ã£o para atualizar o valor da fx
    //Recebe como entrada o id da personalidade a ser atualizada
    private void calculaFx(int i)
    {
        double fx, aux;	
        //aux = 2*x[i]; //para k=2	
        //aux = x[i]; // para k=1;
        aux = this.x[i]/K;//para k=1/8
        this.pAmbiental.setOcean(i, 1/(1+ Math.pow(e, -aux)));//p[i] = 1 / (1 + pow(e,-aux));
        //printf("Personalidade %d atualizada %lf\n",i,p[i]);
        //cout<<p[i];
        
    }



    //Funcao que atualiza x quando Fx tem que diminuir
    private void atualizaXn(int i) 
    {
        if(i>5 && i < 12){//GAMBIARRA PARA DAR METADE DO PESO AS EMOÇÕES DE ESPECTATIVA
            this.divisorFx = 200;
        }
        else{
            this.divisorFx = 100;
        }
        if(x[i]<0)
        {
            //equaÃ§Ã£o anterior : x[i] = x[i] - ((0.5 - p[i])/divisorFx);
            //x[i] = x[i] - ((1 - p[i])/(divisorFx+(tempo/divisorFx))) + ((multFP*(fatorP[i] - p[i]))/(divisorFx+(tempo/divisorFx)));
            this.x[i] -= ((1-this.pAmbiental.getOcean(i))/(this.divisorFx+(this.tempo/this.divisorFx))) + ((this.multFP*(this.pBiologico.getOcean(i)-this.pAmbiental.getOcean(i)))/(divisorFx+(tempo/divisorFx)));
        }
        else
        {
            if(x[i]==0)
                    x[i] = this.X00;
            //x[i] = x[i] - ((1 - p[i])/(divisorFx+(tempo/divisorFx))) + ((multFP*(fatorP[i] - p[i]))/(divisorFx+(tempo/divisorFx)));//original
            x[i] = x[i] - ((1 - this.pAmbiental.getOcean(i))/(divisorFx+(tempo/divisorFx))) + ((multFP*(this.pBiologico.getOcean(i) - this.pAmbiental.getOcean(i)))/(divisorFx+(tempo/divisorFx)));
        }
        tempo++;
        //cout<<x[i];
        
    }

    //FunÃ§Ã£o que atualiza x quando Fx tem que aumentar
    private void atualizaXp(int i)
    {
        
        if(i>5 && i < 12){//GAMBIARRA PARA DAR METADE DO PESO AS EMOÇÕES DE ESPECTATIVA
            this.divisorFx = 200;
        }
        else{
            this.divisorFx = 100;
        }
        if(x[i]<0)
        {
            //x[i] = x[i] + (1-p[i]/(divisorFx));///arrumar
            //x[i] = x[i] + (p[i]/(divisorFx+(tempo/divisorFx))) + ((multFP*(fatorP[i] - p[i]))/(divisorFx+(tempo/divisorFx)));///arrumar  
            x[i] = x[i] + (this.pAmbiental.getOcean(i)/(divisorFx+(tempo/divisorFx))) + ((multFP*(this.pBiologico.getOcean(i) - this.pAmbiental.getOcean(i)))/(divisorFx+(tempo/divisorFx)));///arrumar  
        }
        else 
        {
            if(x[i]==0)
            {
                    x[i]=X00;
                    calculaFx(i);
            }
            //equaÃ§Ã£o anterior : x[i] = x[i] + ((p[i]-0.5)/divisorFx);
            x[i] = x[i] + (this.pAmbiental.getOcean(i)/(divisorFx+(tempo/divisorFx))) + ((multFP*(this.pBiologico.getOcean(i) - this.pAmbiental.getOcean(i)))/(divisorFx+(tempo/divisorFx)));//arrumar
        }
        tempo++;
    }
    
    // FunÃ§Ã£o que encontra a emoÃ§Ã£o a ser sentida
    // Atualmente sÃ³ Ã© verificada o maior peso, posteriormente deve ser feita uma maquina de estados
    private int verificaEmocao()
    {
        
        //Codigo que tentei prob e nao deu muito certo (não uso?)
       
        int k = 0;
        double maior = 0;
        int[] vet = new int[22];
        int rand;
        for(int i=0;i<22;i++){//zerando vet e descobrindo qual é o maior
            vet[i]=0;
            if(this.et.getOcc(i)>maior)
            {
                maior = this.et.getOcc(i);
                //System.out.println("maior");
            }
        }
        for(int i=0;i<22;i++){//verificando qtd de emoções com peso igual
            if(this.et.getOcc(i) == maior){
                vet[k] = i;
                k++;
                if(this.et.getOcc(i)%2 ==0){
                    this.emocoesBoas++;
                }
                else {
                    this.emocoesBoas--;
                }
            }
        }
        //System.out.println(k);
        rand = this.gerador.nextInt(k);//Agora eu escolho um dos maiores aleatoriamente
        return vet[rand];
                
        
        /*
        //Codigo anterior
        int em = 0;
        double aux = 0.0;
        for(int i=0;i<22;i++)
        {
            if(this.et.getOcc(i)>aux)
            {
                aux = this.et.getOcc(i);
                em = i;
            }
        }
        return em;
       //*/
    }
    
    //------------------FunÃ§Ãµes de atualizaÃ§Ã£o das personalidades---------------------------//

//Atualiza Openesses quando algo ruim acontece
    private void atualizaOn()
    {
        atualizaXn(0);
        calculaFx(0);
    }
    //Atualiza Openesses quando algo bom acontece
    private void atualizaOp()
    {
            atualizaXp(0);
            calculaFx(0);
    }
    //Atualiza Conscientiouness quando algo ruim acontece
    private void atualizaCn()
    {
            atualizaXn(1);
            calculaFx(1);
    }
    //Atualiza Conscientiouness quando algo bom acontece
    private void atualizaCp()
    {
            atualizaXp(1);
            calculaFx(1);
    }
    //Atualiza Extrovert quando algo ruim acontece
    private void atualizaEn()
    {
            atualizaXn(2);
            calculaFx(2);
    }
    //Atualiza Extrovert quando algo bom acontece
    private void atualizaEp()
    {
            atualizaXp(2);
            calculaFx(2);
    }
    //Atualiza Amability quando algo ruim acontece
    private void atualizaAn()
    {
            atualizaXn(3);
            calculaFx(3);
    }
    //Atualiza Amability quando algo bom acontece
    private void atualizaAp()
    {
            atualizaXp(3);
            calculaFx(3);
    }
    //Atualiza Neuroticism quando algo ruim acontece
    private void atualizaNn()
    {
            atualizaXn(4);
            calculaFx(4);
    }
    //Atualiza Neuroticism quando algo bom acontece
    private void atualizaNp()
    {
            atualizaXp(4);
            calculaFx(4);
    }
    
// FunÃ§Ã£o que recebe como entrada o id da emoÃ§Ã£o e atualiza as personalidades que referentes a ela
    // FunÃ§Ã£o que atualiza os valores de personalidade
    public void atualizaPersonalidade(int em)//MODIFICADO DE ACORDO COM A SEGUNDA TABELA
    {
	if(em == 0)//Joy
	{
                atualizaOp();
                atualizaCp();
                atualizaEp();
                atualizaAp();
		atualizaNn();
	}
	else if(em == 1)//Distress
	{
                atualizaOn();
                atualizaCn();
                atualizaEn();
                atualizaAn();
		atualizaNp();
	}
	else if(em == 2)//Happy-for
	{
		atualizaNn();
		atualizaAp();
	}
	else if(em == 3)//Pity
	{
		atualizaNp();
		atualizaAp();
	}
	else if(em == 4)//Gloating
	{
		atualizaAn();
		atualizaNn();
	}
	else if(em == 5)//Resentment
	{
		atualizaAn();
		atualizaNp();
	}
	else if(em == 6)//Hope
	{
		atualizaOp();
		atualizaCp();
	}
	else if(em == 7)//Fear
	{
		atualizaOn();
		atualizaCn();
	}
	else if(em == 8)//Satisfaction
	{
		atualizaOp();
		atualizaCp();
		atualizaNn();
	}
	else if(em == 9)//Fears-confirmed
	{
		atualizaOn();
		atualizaCn();
		atualizaNp();
	}
	else if(em == 10)//Relief
	{
		atualizaOp();
		atualizaCp();
		atualizaNn();
	}
	else if(em == 11)//Disapointment
	{
		atualizaOn();
		atualizaCn();
		atualizaNp();
	}
	else if(em == 12)//Pride
	{
		atualizaCp();
		atualizaEp();
	}
	else if(em == 13)//Shame
	{
		atualizaCn();
		atualizaEn();
	}
	else if(em == 14)//Admiration
	{
		atualizaOp();
		atualizaCp();
		atualizaEp();
		atualizaAp();
	}
	else if(em == 15)//Reproach
	{
		atualizaOn();
		atualizaCn();
		atualizaEn();
		atualizaAn();
		//atualizaNp(); //poderiam ser duas vezes pq Reproach tem um peso grande
	}
	else if(em == 16)//Gratification
	{
		atualizaCp();
		atualizaEp();
		atualizaNn();
	}
	else if(em == 17)//Remorse
	{
		atualizaCn();
		atualizaEn();
		atualizaNp();
	}
	else if(em == 18)//Gratitude
	{
		atualizaCp();
		atualizaEp();
		atualizaAp();
		atualizaNn();
	}
	else if(em == 19)//Anger
	{
		atualizaCn();
		atualizaEn();
		atualizaAn();
		atualizaNp();
	}
	else if(em == 20)//Love
	{
		atualizaOp();
		atualizaEp();
		atualizaAp();
		atualizaNn();
	}
	else if(em == 21)//Hate
	{
		atualizaOn();
		atualizaEn();
		atualizaAn();
		atualizaNp();
	}
    }
    
    public void mostraEmocao(int em)
    {
        if(em == 0)
        {
                System.out.println("Joy0");
        }
        else if(em == 1)
        {
                System.out.println("Distress1");
        }
        else if(em == 2)
        {
                System.out.println("Happy-for2");
        }
        else if(em == 3)
        {
                System.out.println("Pity3");
        }
        else if(em == 4)
        {
                System.out.println("Gloating4");
        }
        else if(em == 5)
        {
                System.out.println("Resentment5");
        }
        else if(em == 6)
        {
                System.out.println("Hope6");
        }
        else if(em == 7)
        {
                System.out.println("Fear7");
        }
        else if(em == 8)
        {
                System.out.println("Satisfaction8");
        }
        else if(em == 9)
        {
                System.out.println("Fears-confirmed9");
        }
        else if(em == 10)
        {
                System.out.println("Relief10");
        }
        else if(em == 11)
        {
                System.out.println("Disapointment11");
        }
        else if(em == 12)
        {
                System.out.println("Pride12");
        }
        else if(em == 13)
        {
                System.out.println("Shame13");
        }
        else if(em == 14)
        {
                System.out.println("Admiration14");
        }
        else if(em == 15)
        {
                System.out.println("Reproach15");
        }
        else if(em == 16)
        {
                System.out.println("Gratification16");
        }
        else if(em == 17)
        {
                System.out.println("Remorse17");
        }
        else if(em == 18)
        {
                System.out.println("Gratitude18");
        }
        else if(em == 19)
        {
                System.out.println("Anger19");
        }
        else if(em == 20)
        {
                System.out.println("Love20");
        }
        else if(em == 21)
        {
                System.out.println("Hate21");
        }

    }
}
