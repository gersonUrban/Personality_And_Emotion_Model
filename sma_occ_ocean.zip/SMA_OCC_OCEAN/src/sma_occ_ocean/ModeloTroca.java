/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sma_occ_ocean;

//import jason.environment.grid.GridWorldModel;
//import jason.environment.grid.Location;
import java.util.*;
/**
 *
 * @author Gerson
 */
public class ModeloTroca /*extends GridWorldModel*/ {
    
    private int diasPassados=0;//variavel para contar o numero de iterações
    Agente[] ag;
    final private int qtd;
    
    public ModeloTroca(int qt, Agente[] ag0){
        //Leve gambiarra provisoria porque não existe descrutor em java
        //na main instacio n objetos Agente e toda iteração recebo eles novamente em modeloTroca
        //Então posso fazer x simulações, e começar do zero instanciando a classe de novo.
        qtd = qt;
        ag = new Agente[qtd];
        for(int i=0;i<qtd;i++){
            ag[i] = ag0[i];
            ag[i].inicializaAgente();
        }
        
    }

    public void inicializa(){
        atualiza();
        verificaPropostas();
        diasPassados++;
        if(diasPassados%4 == 0){
            for(int i=0;i<qtd;i++){
                ag[i].addRecurso(5, i);
            }
        }
        verificaAgenteVivo();
        //System.out.println("dias: "+diasPassados+" Ag0: "+ag[0].emocao.modelo.pAmbiental.getOcean('O')+" "+ag[0].emocao.modelo.pAmbiental.getOcean('C')+" "+ag[0].emocao.modelo.pAmbiental.getOcean('E')+" "+ag[0].emocao.modelo.pAmbiental.getOcean('A')+" "+ag[0].emocao.modelo.pAmbiental.getOcean('N'));
    }
    /** ----------------METODOS PARA AS AÇÕES DE UPDATE------------------------*/
    
    //Apenas um teste para visualização de como deve ser a função
    public void atualiza(){
        boolean dt;
        
        for(int i=0;i<qtd;i++){
            dt = ag[i].desejoTroca();
            if(dt){
                //System.out.println("Ag"+ag[i].getId()+" quer trocar!");
                ag[i].setOfertaRecurso(ag[i].calculaOferta());
                ag[i].setUltimoAg(ag[i].escolheAgente());
                ag[i].setEnviaProposta(true);
            }
        }
    }
    
    /** ----------------METODOS PARA AS AÇÕES DE TROCA------------------------*/
    // verificaPropostas() deve estar dentro de update para executar sempre
    void verificaPropostas(){
        boolean p;
        boolean m;
        //Verificando se o ag0 quer fazer troca
        for(int i=0;i<qtd;i++){
            p = ag[i].getEnviaProposta();
            if(p){
                ag[i].setEnviaProposta(false);
                enviaMenssagem(ag[i].getId(), ag[i].getUltimoAg(), ag[i].ofertaRecurso);
            }
        }
    }
    
   //Enviar msg da proposta para outro agente
    void enviaMenssagem(int id1, int id2, Mercadoria p){// gambiarra pq não manjo java
        setAgsTrocando(id1,id2); // deixa os dois busy = true
        boolean resposta = ag[id2].avaliaProposta(id1, p);
        if(resposta){
            //System.out.println("Solicitacao de ag"+ag[id1].getId()+ "Aceita");
            efetuarTroca(id1,id2,p);
            trocaAceita(id1,true);
        }
        else{
            //System.out.println("Solicitacao de ag"+ag[id1].getId()+ "Negada");
            trocaAceita(id1,false);
        }
        setAgsLiberados(id1,id2);//setando Busy = false
    }
    
    void setReceberSolicitacao(int id, boolean b){
        ag[id].emocao.setReceberSolicitacao(b);
    }
    //verifica se o ag(id) está ocupado
    boolean verificaOcupado(int id){
        for(int i=0;i<qtd;i++){
            if(ag[i].getId() == id){
                return ag[i].getBusy();
            }
        }
        return true;
    }
    
    
    void efetuarTroca(int id1, int id2, Mercadoria p){
        //System.out.println("Efetuando troca entre ag"+ag[id1].getId()+ " e ag"+ag[id2].getId());
        ag[id1].subRecurso(p.m1, id1);
        ag[id2].subRecurso(p.m2, id2);
        ag[id1].addRecurso(p.m2, id2);
        ag[id2].addRecurso(p.m1, id1);
    }
    
    void trocaAceita(int id, boolean t){
            ag[id].setTrocaAceita(t);//-----------PRECISO DELETAR ??
            ag[id].emocao.setTrocaAceita(t);
            ag[id].emocao.calculaEmocaoRealizacao();//----------COLOCAR DENTRO DO AGENTE
            if(t){ag[id].calculaTrocaBoa();}
            ag[id].fimDia();
    }
    
    void setAgsTrocando(int id1, int id2){
        ag[id1].setBusy(true);
        ag[id2].setBusy(true);
        ag[id2].emocao.setReceberSolicitacao(true);
    }
    
    void setAgsLiberados(int id1, int id2){
        ag[id1].setBusy(false);
        ag[id2].setBusy(false);
    }
    
    void verificaAgenteVivo(){
        for(int i=0;i<qtd;i++){
            if(ag[i].getEstouVivo() == false){
                for(int j=0;j<qtd;j++){
                    if(j!=i){
                        ag[j].setAgenteMorto(i);
                    }
                }
            }
        }
    }
    
}
