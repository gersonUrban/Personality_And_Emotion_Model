/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sma_occ_ocean;

/**
 *
 * @author Gerson
 */
public class Ocean {
    private double[] OCEAN = new double[5];
    
    
    
    Ocean(){
        //recebendo os valores OCEAN do agente
        this.OCEAN[0] = 0.5;//O;
        this.OCEAN[1] = 0.5;//C;
        this.OCEAN[2] = 0.5;//E;
        this.OCEAN[3] = 0.5;//A;
        this.OCEAN[4] = 0.5;//N;
    }
    Ocean(double O, double C, double E, double A, double N){
        //recebendo os valores OCEAN do agente
        this.OCEAN[0] = O;
        this.OCEAN[1] = C;
        this.OCEAN[2] = E;
        this.OCEAN[3] = A;
        this.OCEAN[4] = N;
    }
    
    public void setOcean(int i, double valor){
        this.OCEAN[i] = valor;
    }
    public double getOcean(int i){
        return this.OCEAN[i];
    }
    
    //Getter and Setter OCEAN
    public double getOcean(char ocean){
            switch (ocean){
                    case 'O':
                            return this.OCEAN[0];
                    case 'C':
                            return this.OCEAN[1];
                    case 'E':
                            return this.OCEAN[2];
                    case 'A':
                            return this.OCEAN[3];
                    case 'N':
                            return this.OCEAN[4];
                    default:
                            return 0;
            }
    }
    public void setOcean(double valor, char ocean){
            switch (ocean){
                    case 'O':
                            this.OCEAN[0] = valor;
                            break;
                    case 'C':
                            this.OCEAN[1] = valor;
                            break;
                    case 'E':
                            this.OCEAN[2] = valor;
                            break;
                    case 'A':
                            this.OCEAN[3] = valor;
                            break;
                    case 'N':
                            this.OCEAN[4] = valor;
                            break;
            }
    }
 
     
}
