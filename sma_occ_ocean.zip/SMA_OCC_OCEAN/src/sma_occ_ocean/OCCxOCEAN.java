/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sma_occ_ocean;
import java.util.Random; 
import java.lang.Math;
/**
 *
 * @author Gerson / Christian
 */
public class OCCxOCEAN {
    private final double[][] matriz = new double[22][5];
    Random gerador = new Random();
    private float dp;
    private float aux;
    
    OCCxOCEAN(int k){
        // Openness - Conscientiousness - Extraversion - Agreeableness ---- Neuroticism
        matriz[0][0]=0.6;matriz[0][1]=0.6;matriz[0][2]=0.6;matriz[0][3]=0.6;matriz[0][4]=0.2;//Joy
        matriz[1][0]=0.4;matriz[1][1]=0.4;matriz[1][2]=0.4;matriz[1][3]=0.4;matriz[1][4]=0.8;//Distress

        matriz[2][0]=0.6;matriz[2][1]=0.6;matriz[2][2]=0.6;matriz[2][3]=0.8;matriz[2][4]=0.2;//Happy-for
        matriz[3][0]=0.4;matriz[3][1]=0.4;matriz[3][2]=0.4;matriz[3][3]=0.2;matriz[3][4]=0.8;//Pity
        matriz[4][0]=0.6;matriz[4][1]=0.6;matriz[4][2]=0.6;matriz[4][3]=0.8;matriz[4][4]=0.2;//Gloating
        matriz[5][0]=0.4;matriz[5][1]=0.4;matriz[5][2]=0.4;matriz[5][3]=0.2;matriz[5][4]=0.8;//Resentment

        matriz[6][0]=0.8;matriz[6][1]=0.8;matriz[6][2]=0.6;matriz[6][3]=0.6;matriz[6][4]=0.2;//Hope
        matriz[7][0]=0.2;matriz[7][1]=0.2;matriz[7][2]=0.4;matriz[7][3]=0.4;matriz[7][4]=0.8;//Fear
        matriz[8][0]=0.8;matriz[8][1]=0.8;matriz[8][2]=0.6;matriz[8][3]=0.6;matriz[8][4]=0.2;//Satisfaction
        matriz[9][0]=0.2;matriz[9][1]=0.2;matriz[9][2]=0.4;matriz[9][3]=0.4;matriz[9][4]=0.8;//Fears-Confirmed
        matriz[10][0]=0.8;matriz[10][1]=0.8;matriz[10][2]=0.6;matriz[10][3]=0.6;matriz[10][4]=0.2;//Relief
        matriz[11][0]=0.2;matriz[11][1]=0.2;matriz[11][2]=0.4;matriz[11][3]=0.4;matriz[11][4]=0.8;//Disapointment

        matriz[12][0]=0.6;matriz[12][1]=0.8;matriz[12][2]=0.8;matriz[12][3]=0.6;matriz[12][4]=0.2;//Pride
        matriz[13][0]=0.4;matriz[13][1]=0.2;matriz[13][2]=0.2;matriz[13][3]=0.4;matriz[13][4]=0.8;//Shame
        matriz[14][0]=0.8;matriz[14][1]=0.8;matriz[14][2]=0.8;matriz[14][3]=0.8;matriz[14][4]=0.2;//Admiration
        matriz[15][0]=0.2;matriz[15][1]=0.2;matriz[15][2]=0.2;matriz[15][3]=0.2;matriz[15][4]=0.8;//Reproach

        matriz[16][0]=0.6;matriz[16][1]=0.8;matriz[16][2]=0.8;matriz[16][3]=0.6;matriz[16][4]=0.2;//Gratification
        matriz[17][0]=0.4;matriz[17][1]=0.2;matriz[17][2]=0.2;matriz[17][3]=0.4;matriz[17][4]=0.8;//Remorse
        matriz[18][0]=0.6;matriz[18][1]=0.8;matriz[18][2]=0.8;matriz[18][3]=0.8;matriz[18][4]=0.2;//Gratitude
        matriz[19][0]=0.4;matriz[19][1]=0.2;matriz[19][2]=0.2;matriz[19][3]=0.2;matriz[19][4]=0.8;//Anger

        matriz[20][0]=0.8;matriz[20][1]=0.6;matriz[20][2]=0.8;matriz[20][3]=0.8;matriz[20][4]=0.2;//Love
        matriz[21][0]=0.2;matriz[21][1]=0.4;matriz[21][2]=0.2;matriz[21][3]=0.2;matriz[21][4]=0.8;//Hate
        
        dp = (float) 0.1;
                
        for(int i=0;i<22;i++){
            for(int j=0;j<5;j++){
                aux = (float) matriz[i][j];
                matriz[i][j] = (float) ((float) (Math.random() * ((aux + dp) - (aux - dp)) + (aux - dp)));
                //System.out.println(matriz[i][j]);
            }
        }
        
        
        if(k==1){
            for(int i=0;i<22;i++){
                for(int j=0;j<5;j++){
                    matriz[i][j]= 1 - matriz[i][j];
                }
            }
        }
    }
    
    public double getOCCxOCEAN(int i, int j){
        return this.matriz[i][j];
    }
    public void setOCCxOCEAN(int i, int j, double x){
        this.matriz[i][j] = x;
    }
    
}
