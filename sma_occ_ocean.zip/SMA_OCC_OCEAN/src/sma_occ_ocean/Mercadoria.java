/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sma_occ_ocean;

//import java.util.*;

/**
 *
 * @author Gerson
 */
public class Mercadoria {
    public int m1;
    public int m2;
    
    public Mercadoria(){    
        this.m1 = 1;
        this.m2 = 1;
    }
    
    
}
